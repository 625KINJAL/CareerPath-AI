import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from career_model import recommend, load_roles

st.set_page_config(page_title="CareerPath AI", page_icon="🎯", layout="wide")
st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#081426 0%,#101d36 55%,#171b3d 100%); color:#f5f7ff;}
[data-testid="stHeader"] {background:transparent;}
.block-container {padding-top:2rem; max-width:1250px;}
.hero {padding:28px 30px;border:1px solid #33476b;border-radius:22px;background:linear-gradient(120deg,#172b4d,#30265c);margin-bottom:22px;}
.hero h1 {font-size:2.35rem;margin:0;color:#fff;}
.hero p {color:#c6d3ee;font-size:1.05rem;margin:8px 0 0;}
.panel {background:#14233d;border:1px solid #304566;border-radius:16px;padding:18px 20px;margin:8px 0;}
.small {color:#aebed9;font-size:.9rem;}
.metric {font-size:1.8rem;font-weight:700;color:#9dd8ff;}
div.stButton>button {background:linear-gradient(90deg,#5b8cff,#916bff);color:white;border:0;border-radius:10px;font-weight:700;}
</style>
""", unsafe_allow_html=True)

if "results" not in st.session_state:
    st.session_state.results = None

st.markdown("""
<div class="hero">
  <h1>🎯 CareerPath AI</h1>
  <p>Intelligent Career Guidance & Job Role Recommendation System</p>
  <p class="small">Explore career paths, understand your skill gaps, and plan your next learning steps.</p>
</div>
""", unsafe_allow_html=True)

left, right = st.columns([1.08, 0.92], gap="large")
with left:
    st.subheader("👤 Build your student profile")
    education = st.selectbox("Highest education", ["Diploma", "BCA / BSc", "B.Tech / BE", "MCA / MSc", "M.Tech / ME", "MBA", "Other"])
    field = st.selectbox("Study specialization", ["Computer Science", "Data Science", "Artificial Intelligence", "Information Technology", "Electronics", "Business", "Design", "Other"])
    experience = st.selectbox("Experience level", ["Fresher", "Internship", "Less than 1 year", "1–3 years", "3–5 years", "5+ years"])
    skills = st.text_area("Your skills (comma-separated)", placeholder="Example: Python, SQL, Machine Learning, Pandas, Excel", height=105)
    interests = st.text_area("Career interests", placeholder="Example: AI, data analytics, software development", height=75)
    projects = st.text_area("Projects or certifications (optional)", placeholder="Example: House price prediction project, Python certification", height=65)
    uploaded = st.file_uploader("Upload resume (optional: PDF, DOCX or TXT)", type=["pdf","docx","txt"])
    if st.button("✨ Analyze My Career", use_container_width=True):
        resume_text = ""
        if uploaded:
            try:
                if uploaded.name.lower().endswith(".pdf"):
                    from pypdf import PdfReader
                    reader = PdfReader(uploaded)
                    resume_text = " ".join(page.extract_text() or "" for page in reader.pages)
                elif uploaded.name.lower().endswith(".docx"):
                    from docx import Document
                    doc = Document(uploaded)
                    resume_text = " ".join(p.text for p in doc.paragraphs)
                else:
                    resume_text = uploaded.read().decode("utf-8", errors="ignore")
            except Exception as e:
                st.warning(f"Could not read the uploaded resume: {e}")
        profile = " ".join([education, field, experience, skills, interests, projects, resume_text]).strip()
        if len(profile) < 12:
            st.error("Please enter your education and at least a few skills or interests.")
        else:
            with st.spinner("Analyzing your profile and matching career paths..."):
                st.session_state.results, st.session_state.model_score = recommend(profile, 3)
                st.session_state.profile = profile
            st.success("Career analysis completed.")

with right:
    st.subheader("📊 What you will receive")
    st.markdown('<div class="panel"><div class="metric">Top 3</div><b>Career role matches</b><div class="small">Ranked suggestions based on the profile you provide.</div></div>', unsafe_allow_html=True)
    st.markdown('<div class="panel"><div class="metric">Skill gap</div><b>Skills to strengthen</b><div class="small">Compare your profile with the skill profile for each suggested role.</div></div>', unsafe_allow_html=True)
    st.markdown('<div class="panel"><div class="metric">Roadmap</div><b>Actionable learning guidance</b><div class="small">A practical next-step description for each career direction.</div></div>', unsafe_allow_html=True)
    st.info("Tip: List specific skills such as Python, SQL, Power BI, React, Linux, or Figma for more useful matching.")

if st.session_state.results:
    st.divider()
    st.header("🚀 Your career recommendations")
    results = st.session_state.results
    cols = st.columns(3)
    for col, item in zip(cols, results):
        with col:
            st.markdown('<div class="panel">', unsafe_allow_html=True)
            st.subheader(item["role"])
            st.caption(item["category"])
            st.metric("Model match score", f'{item["model_score"]*100:.1f}%')
            st.write("**Matched skills**")
            st.write(", ".join(item["matched_skills"]) if item["matched_skills"] else "Add role-specific skills to your profile.")
            st.write("**Skills to develop**")
            st.write(", ".join(item["missing_skills"][:6]) if item["missing_skills"] else "Your listed skills cover this role's sample skill profile.")
            st.write("**Indicative India salary range**")
            st.write(f'₹{item["salary_min_lpa"]:g}–{item["salary_max_lpa"]:g} LPA')
            st.caption("Broad illustrative estimate; actual pay varies by location, company, experience and market.")
            st.write("**Suggested roadmap**")
            st.write(item["roadmap"])
            st.markdown('</div>', unsafe_allow_html=True)

    st.subheader("📈 Compare your top role matches")
    chart_df = pd.DataFrame({"Career role":[r["role"] for r in results],
                             "Model match score (%)":[round(r["model_score"]*100,1) for r in results]})
    st.bar_chart(chart_df.set_index("Career role"))
    st.caption(f"Internal holdout accuracy on synthetic training examples: {st.session_state.model_score*100:.1f}%. This is a software demonstration metric, not real-world hiring accuracy.")
    report = pd.DataFrame([{
        "Recommended role":r["role"], "Category":r["category"],
        "Model match score (%)":round(r["model_score"]*100,1),
        "Matched skills":", ".join(r["matched_skills"]),
        "Skills to develop":", ".join(r["missing_skills"]),
        "Indicative salary min (LPA)":r["salary_min_lpa"],
        "Indicative salary max (LPA)":r["salary_max_lpa"],
        "Roadmap":r["roadmap"]
    } for r in results])
    st.download_button("⬇️ Download career report (CSV)", report.to_csv(index=False).encode("utf-8"),
                       file_name="careerpath_ai_report.csv", mime="text/csv")

with st.expander("ℹ️ About this academic prototype"):
    st.write("This project demonstrates a machine-learning career-role recommender. Its role profiles and salary bands are curated educational examples, and its training variations are synthetic. The model score indicates similarity learned by this prototype; it is not the probability of getting hired, a guarantee of employment, or a validated salary forecast. Use the recommendations as guidance and verify current job requirements independently.")
    st.write("Model: TF-IDF text features + Logistic Regression classifier. Skill-gap analysis compares entered profile text with curated role skill lists.")

st.markdown("---")
st.caption("CareerPath AI | M.Tech AIML Academic Project | Built with Python, Streamlit, Pandas and Scikit-learn")
